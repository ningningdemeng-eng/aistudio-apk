package com.aistudio.app

import java.io.BufferedInputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URI
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 轻量本地 HTTP/HTTPS 代理，用于解决 Android 缺少 /etc/resolv.conf 导致 Go 静态二进制无法解析 DNS 的问题。
 * 所有流量走 Android 原生 Socket，自动兼容手机自身的梯子/VPN/WiFi/流量网络。
 */
class LocalDnsProxy(private val port: Int = 18080) {

    private val running = AtomicBoolean(false)
    private var serverSocket: ServerSocket? = null
    private val pool = Executors.newCachedThreadPool()

    fun isAlive(): Boolean = running.get() && serverSocket?.isClosed == false

    fun start() {
        if (!running.compareAndSet(false, true)) return
        pool.execute {
            try {
                serverSocket = ServerSocket(port, 64, InetAddress.getByName("127.0.0.1"))
                while (running.get()) {
                    val client = serverSocket?.accept() ?: break
                    pool.execute { handleClient(client) }
                }
            } catch (_: Exception) {
            } finally {
                running.set(false)
            }
        }
    }

    fun stop() {
        running.set(false)
        try { serverSocket?.close() } catch (_: Exception) {}
        serverSocket = null
    }

    private fun handleClient(client: Socket) {
        var target: Socket? = null
        try {
            client.soTimeout = 60_000
            val input = BufferedInputStream(client.getInputStream())
            val output = client.getOutputStream()

            val requestLine = readLine(input) ?: return
            val parts = requestLine.split(" ")
            if (parts.size < 3) return

            val method = parts[0]
            val targetStr = parts[1]
            val version = parts[2]

            val headers = mutableListOf<String>()
            while (true) {
                val line = readLine(input) ?: break
                if (line.isEmpty()) break
                headers.add(line)
            }

            if (method.equals("CONNECT", ignoreCase = true)) {
                val colonIdx = targetStr.lastIndexOf(':')
                val host = if (colonIdx > 0) targetStr.substring(0, colonIdx).trim('[', ']') else targetStr
                val targetPort = if (colonIdx > 0) targetStr.substring(colonIdx + 1).toIntOrNull() ?: 443 else 443

                target = Socket(host, targetPort)
                target.soTimeout = 0
                client.soTimeout = 0

                output.write("HTTP/1.1 200 Connection Established\r\n\r\n".toByteArray())
                output.flush()

                val tSocket = target
                val t1 = pool.submit { pipe(input, tSocket.getOutputStream()) }
                pipe(tSocket.getInputStream(), output)
                try { t1.get() } catch (_: Exception) {}
            } else {
                val uri = URI(targetStr)
                val host = uri.host ?: return
                val targetPort = if (uri.port > 0) uri.port else 80
                val path = (uri.rawPath?.ifEmpty { "/" } ?: "/") +
                    (if (uri.rawQuery != null) "?${uri.rawQuery}" else "")

                target = Socket(host, targetPort)
                val targetOut = target.getOutputStream()
                val sb = StringBuilder()
                sb.append("$method $path $version\r\n")
                for (h in headers) {
                    if (!h.startsWith("Proxy-Connection:", ignoreCase = true)) {
                        sb.append(h).append("\r\n")
                    }
                }
                sb.append("Connection: close\r\n\r\n")
                targetOut.write(sb.toString().toByteArray())
                targetOut.flush()

                val tSocket = target
                val t1 = pool.submit { pipe(input, tSocket.getOutputStream()) }
                pipe(tSocket.getInputStream(), output)
                try { t1.get() } catch (_: Exception) {}
            }
        } catch (_: Exception) {
        } finally {
            try { target?.close() } catch (_: Exception) {}
            try { client.close() } catch (_: Exception) {}
        }
    }

    private fun readLine(input: InputStream): String? {
        val sb = StringBuilder()
        var b = input.read()
        if (b == -1) return null
        while (b != -1) {
            if (b == '\n'.code) break
            if (b != '\r'.code) sb.append(b.toChar())
            b = input.read()
        }
        return sb.toString()
    }

    private fun pipe(input: InputStream, output: OutputStream) {
        try {
            val buf = ByteArray(16384)
            while (true) {
                val n = input.read(buf)
                if (n <= 0) break
                output.write(buf, 0, n)
                output.flush()
            }
        } catch (_: Exception) {}
    }
}
