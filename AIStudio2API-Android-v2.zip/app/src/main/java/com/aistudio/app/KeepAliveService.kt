package com.aistudio.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Base64
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyStore
import java.util.concurrent.atomic.AtomicBoolean
import javax.net.ssl.TrustManagerFactory
import javax.net.ssl.X509TrustManager

class KeepAliveService : Service() {

    companion object {
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val LOCAL_PROXY_PORT = 18080
        val isRunning = AtomicBoolean(false)
    }

    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var silentTrack: AudioTrack? = null
    private var dnsProxy: LocalDnsProxy? = null
    private var coreProcess: Process? = null
    private var watchdogThread: Thread? = null
    private var heartbeatThread: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopAll()
            stopSelf()
            return START_NOT_STICKY
        }

        if (isRunning.compareAndSet(false, true)) {
            startForegroundNotification()
            acquireLocks()
            startSilentAudio()
            startLocalProxy()
            startCoreWatchdog()
            startTenSecondHeartbeat()
        }
        return START_STICKY
    }

    private fun startLocalProxy() {
        dnsProxy = LocalDnsProxy(LOCAL_PROXY_PORT).apply { start() }
    }

    /**
     * 后台静音音频播放：防真我/ColorOS 墓碑冻结机制，不抢占音频焦点（不影响听歌）
     */
    private fun startSilentAudio() {
        try {
            val sampleRate = 8000
            val bufferSize = sampleRate * 2 // 1秒 16-bit 单声道静音数据
            val silence = ByteArray(bufferSize)

            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            track.write(silence, 0, silence.size)
            track.setLoopPoints(0, sampleRate, -1)
            track.setVolume(0.001f)
            track.play()
            silentTrack = track
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * 10秒心跳保活：每10秒检测一次本地服务与代理，保持进程与网络活跃不挂机
     */
    private fun startTenSecondHeartbeat() {
        heartbeatThread = Thread {
            while (isRunning.get()) {
                try {
                    Thread.sleep(10_000)
                    if (!isRunning.get()) break

                    // 确保本地 DNS 代理存活
                    if (dnsProxy?.isAlive() != true) {
                        dnsProxy?.stop()
                        startLocalProxy()
                    }

                    // 确保静音播放未被系统意外暂停
                    if (silentTrack?.playState != AudioTrack.PLAYSTATE_PLAYING) {
                        try { silentTrack?.play() } catch (_: Exception) {}
                    }

                    // 轻量访问本地端口保持后端活跃
                    try {
                        val conn = URL("http://127.0.0.1:2048/").openConnection() as HttpURLConnection
                        conn.connectTimeout = 2000
                        conn.readTimeout = 2000
                        conn.requestMethod = "HEAD"
                        conn.responseCode
                        conn.disconnect()
                    } catch (_: Exception) {}
                } catch (_: InterruptedException) {
                    break
                } catch (_: Exception) {}
            }
        }.apply { start() }
    }

    /**
     * 导出系统受信任 CA 证书，解决 Go 静态程序在 Android 上 HTTPS 报错问题
     */
    private fun exportSystemCaCerts(destFile: File) {
        try {
            val tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
            tmf.init(null as KeyStore?)
            val x509Tm = tmf.trustManagers.filterIsInstance<X509TrustManager>().firstOrNull() ?: return
            val sb = StringBuilder()
            for (cert in x509Tm.acceptedIssuers) {
                val encoded = Base64.encodeToString(cert.encoded, Base64.NO_WRAP)
                sb.append("-----BEGIN CERTIFICATE-----\n")
                var i = 0
                while (i < encoded.length) {
                    sb.append(encoded.substring(i, minOf(i + 64, encoded.length))).append("\n")
                    i += 64
                }
                sb.append("-----END CERTIFICATE-----\n")
            }
            destFile.writeText(sb.toString())
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun startCoreWatchdog() {
        val binPath = "${applicationInfo.nativeLibraryDir}/libaistudio2api.so"
        val workDir = File(filesDir, "data").apply { mkdirs() }
        val caFile = File(workDir, "cacerts.pem")
        exportSystemCaCerts(caFile)

        val envFile = File(workDir, ".env")
        if (!envFile.exists()) {
            envFile.writeText(
                """
                HOST=0.0.0.0
                PORT=2048
                AUTO_START=true
                WAA_BACKEND=spidermonkey
                """.trimIndent() + "\n"
            )
        }

        val proxyAddr = "http://127.0.0.1:$LOCAL_PROXY_PORT"

        watchdogThread = Thread {
            while (isRunning.get()) {
                try {
                    val pb = ProcessBuilder(binPath, "-open-ui=false")
                        .directory(workDir)
                        .redirectErrorStream(true)

                    val env = pb.environment()
                    env["HOME"] = workDir.absolutePath
                    env["TMPDIR"] = cacheDir.absolutePath
                    env["SSL_CERT_FILE"] = caFile.absolutePath
                    env["HTTP_PROXY"] = proxyAddr
                    env["HTTPS_PROXY"] = proxyAddr
                    env["http_proxy"] = proxyAddr
                    env["https_proxy"] = proxyAddr
                    env["NO_PROXY"] = "127.0.0.1,localhost,::1"
                    env["no_proxy"] = "127.0.0.1,localhost,::1"

                    coreProcess = pb.start()
                    coreProcess?.inputStream?.bufferedReader()?.forEachLine { }
                    coreProcess?.waitFor()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                if (isRunning.get()) {
                    try {
                        Thread.sleep(2000)
                    } catch (_: InterruptedException) {
                        break
                    }
                }
            }
        }.apply { start() }
    }

    private fun startForegroundNotification() {
        val channelId = "aistudio_keepalive_v2"
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(channelId) == null) {
            nm.createNotificationChannel(
                NotificationChannel(channelId, "AIStudio2API 后台保活", NotificationManager.IMPORTANCE_LOW)
            )
        }

        val openPi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, KeepAliveService::class.java).apply { action = ACTION_STOP }
        val stopPi = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification = Notification.Builder(this, channelId)
            .setContentTitle("AIStudio2API 后台运行中")
            .setContentText("静音保活 + 10秒心跳已开启 | 127.0.0.1:2048")
            .setSmallIcon(android.R.drawable.stat_sys_upload_done)
            .setContentIntent(openPi)
            .addAction(Notification.Action.Builder(null, "停止服务", stopPi).build())
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(1, notification)
        }
    }

    private fun acquireLocks() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AIStudio2API::KeepAlive").apply {
            acquire()
        }

        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            WifiManager.WIFI_MODE_FULL_LOW_LATENCY
        } else {
            @Suppress("DEPRECATION")
            WifiManager.WIFI_MODE_FULL_HIGH_PERF
        }
        wifiLock = wm.createWifiLock(mode, "AIStudio2API::WifiKeepAlive").apply {
            acquire()
        }
    }

    private fun stopAll() {
        isRunning.set(false)
        heartbeatThread?.interrupt()
        watchdogThread?.interrupt()
        coreProcess?.destroyForcibly()
        coreProcess = null
        dnsProxy?.stop()
        dnsProxy = null
        try {
            silentTrack?.stop()
            silentTrack?.release()
        } catch (_: Exception) {}
        silentTrack = null
        if (wakeLock?.isHeld == true) wakeLock?.release()
        if (wifiLock?.isHeld == true) wifiLock?.release()
    }

    override fun onDestroy() {
        stopAll()
        super.onDestroy()
    }
}
