package com.aistudio.app

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.net.VpnService
import android.os.Bundle
import android.provider.Settings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {

    private lateinit var proxyInput: EditText
    private lateinit var webView: WebView

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            launchService(KeepAliveVpnService.ACTION_START_VPN)
        } else {
            Toast.makeText(this, "未授予VPN权限，无法开启最高优先级模式", Toast.LENGTH_SHORT).show()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 48, 24, 16)
        }

        proxyInput = EditText(this).apply {
            hint = "可选代理，如 http://127.0.0.1:7890（直连留空）"
        }

        val btnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        val btnVpnStart = Button(this).apply {
            text = "VPN强保活启动"
            setOnClickListener {
                requestIgnoreBattery()
                val intent = VpnService.prepare(this@MainActivity)
                if (intent != null) {
                    vpnPermissionLauncher.launch(intent)
                } else {
                    launchService(KeepAliveVpnService.ACTION_START_VPN)
                }
            }
        }

        val btnNormalStart = Button(this).apply {
            text = "兼容模式启动"
            setOnClickListener {
                requestIgnoreBattery()
                launchService(KeepAliveVpnService.ACTION_START_NORMAL)
            }
        }

        val btnStop = Button(this).apply {
            text = "停止"
            setOnClickListener {
                startService(Intent(this@MainActivity, KeepAliveVpnService::class.java).apply {
                    action = KeepAliveVpnService.ACTION_STOP
                })
                Toast.makeText(this@MainActivity, "服务已停止", Toast.LENGTH_SHORT).show()
            }
        }

        btnRow.addView(btnVpnStart)
        btnRow.addView(btnNormalStart)
        btnRow.addView(btnStop)

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }

        root.addView(proxyInput)
        root.addView(btnRow)
        root.addView(webView)
        setContentView(root)

        if (KeepAliveVpnService.isRunning.get()) {
            webView.loadUrl("http://127.0.0.1:2048")
        }
    }

    private fun launchService(action: String) {
        val intent = Intent(this, KeepAliveVpnService::class.java).apply {
            this.action = action
            putExtra(KeepAliveVpnService.EXTRA_PROXY, proxyInput.text.toString().trim())
        }
        startForegroundService(intent)
        Toast.makeText(this, "正在启动后端，3秒后加载面板...", Toast.LENGTH_SHORT).show()
        webView.postDelayed({ webView.loadUrl("http://127.0.0.1:2048") }, 3000)
    }

    @SuppressLint("BatteryLife")
    private fun requestIgnoreBattery() {
        try {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:$packageName")
            }
            startActivity(intent)
        } catch (_: Exception) {}
    }
}
