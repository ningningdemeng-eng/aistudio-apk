package com.aistudio.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.PowerManager
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

class KeepAliveVpnService : VpnService() {

    companion object {
        const val ACTION_START_VPN = "ACTION_START_VPN"
        const val ACTION_START_NORMAL = "ACTION_START_NORMAL"
        const val ACTION_STOP = "ACTION_STOP"
        const val EXTRA_PROXY = "EXTRA_PROXY"
        val isRunning = AtomicBoolean(false)
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var coreProcess: Process? = null
    private var watchdogThread: Thread? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopAll()
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START_VPN, ACTION_START_NORMAL -> {
                val useVpn = intent.action == ACTION_START_VPN
                val proxyUrl = intent.getStringExtra(EXTRA_PROXY) ?: ""
                if (isRunning.compareAndSet(false, true)) {
                    startForegroundNotification(useVpn)
                    acquireWakeLock()
                    if (useVpn) setupDummyVpn()
                    startCoreWatchdog(proxyUrl)
                }
            }
        }
        return START_STICKY
    }

    private fun setupDummyVpn() {
        try {
            val builder = Builder()
                .setSession("AIStudio2API 最高优先级保活")
                .addAddress("10.255.255.1", 32)
                // 仅路由保留测试IP，不拦截任何真实网络流量
                .addRoute("198.18.0.1", 32)
                .setMtu(1500)
            vpnInterface = builder.establish()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun startCoreWatchdog(proxyUrl: String) {
        val binPath = "${applicationInfo.nativeLibraryDir}/libaistudio2api.so"
        val workDir = File(filesDir, "data").apply { mkdirs() }

        val envFile = File(workDir, ".env")
        if (!envFile.exists()) {
            envFile.writeText(
                """
                HOST=0.0.0.0
                PORT=2048
                AUTO_START=true
                WAA_BACKEND=spidermonkey
                """.trimIndent() + "\n"
            )
        }

        watchdogThread = Thread {
            while (isRunning.get()) {
                try {
                    val pb = ProcessBuilder(binPath, "-open-ui=false")
                        .directory(workDir)
                        .redirectErrorStream(true)

                    val env = pb.environment()
                    env["HOME"] = workDir.absolutePath
                    env["TMPDIR"] = cacheDir.absolutePath
                    if (proxyUrl.isNotBlank()) {
                        env["PROXY"] = proxyUrl
                        env["HTTP_PROXY"] = proxyUrl
                        env["HTTPS_PROXY"] = proxyUrl
                    }

                    coreProcess = pb.start()
                    coreProcess?.inputStream?.bufferedReader()?.forEachLine { }
                    coreProcess?.waitFor()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                if (isRunning.get()) {
                    try {
                        Thread.sleep(3000)
                    } catch (_: InterruptedException) {
                        break
                    }
                }
            }
        }.apply { start() }
    }

    private fun startForegroundNotification(useVpn: Boolean) {
        val channelId = "aistudio_keepalive"
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(channelId) == null) {
            nm.createNotificationChannel(
                NotificationChannel(channelId, "AIStudio2API 保活服务", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val modeText = if (useVpn) "VPN最高优先级保活中" else "前台服务保活中"
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("AIStudio2API 运行中")
            .setContentText("$modeText | http://127.0.0.1:2048")
            .setSmallIcon(android.R.drawable.stat_sys_upload_done)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notification)
        }
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AIStudio2API::KeepAlive")
        wakeLock?.acquire()
    }

    private fun stopAll() {
        isRunning.set(false)
        coreProcess?.destroyForcibly()
        coreProcess = null
        watchdogThread?.interrupt()
        try { vpnInterface?.close() } catch (_: Exception) {}
        vpnInterface = null
        if (wakeLock?.isHeld == true) wakeLock?.release()
    }

    override fun onRevoke() {
        try { vpnInterface?.close() } catch (_: Exception) {}
        vpnInterface = null
    }

    override fun onDestroy() {
        stopAll()
        super.onDestroy()
    }
}
